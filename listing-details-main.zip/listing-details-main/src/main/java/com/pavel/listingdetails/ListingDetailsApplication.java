package com.pavel.listingdetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListingDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListingDetailsApplication.class, args);
	}

}
